Instrucciones para ver la página:

1. Abre el archivo index.html en tu navegador web haciendo doble clic.
2. Para subir a GitHub Pages:
   - Crea un repositorio en GitHub.
   - Sube este archivo index.html.
   - En 'Settings > Pages', selecciona la rama 'main' y carpeta '/'.
   - Accede al link generado para ver tu página online.
